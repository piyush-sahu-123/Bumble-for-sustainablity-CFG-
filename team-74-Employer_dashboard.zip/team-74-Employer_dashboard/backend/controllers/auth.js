const { Employee } = require("../models/employee");
const { Employer } = require("../models/employer");
const { Referral } = require("../models/referral");
const { uploadFile } = require("../functions/cloudinary");

const bcrypt = require("bcryptjs");

const signUp = async (req, res) => {
    const {
        username,
        email,
        password,
        referral
    } = req.body;

    try {
        const hashcode = referral
        const check_referal = await Referral.findOne({ hashcode })
        if (!check_referal)
            return res.status(400).json({ msg: "Referral doesn't exist" })

        const check_user = await Employee.findOne({ email })
        if (check_user) {
            return res.status(400).json({
                msg: "User Already Exists"
            });
        }

        employee = new Employee({
            username,
            email,
            password,
        });

        const salt = await bcrypt.genSalt(10);
        employee.password = await bcrypt.hash(password, salt);

        await employee.save()
        res.status(201).json(employee);
    } catch (error) {
        res.status(400).json({ error: error.message })
    }
}


const login = async (req, res) => {
    const { email, password } = req.body;

    try {
        let employee = await Employee.findOne({
            email
        });
        if (!employee)
            return res.status(400).json({
                message: "User doesn't exist"
            });

        const isMatch = await bcrypt.compare(password, employee.password);
        if (!isMatch)
            return res.status(400).json({
                message: "Incorrect Password !"
            });

        res.status(200).json(employee);

    } catch (error) {
        res.status(400).json({ error: error.message })
    }
}


const loginEmployer = async (req, res) => {
    const { email, password } = req.body;

    try {
        let employer = await Employer.findOne({
            email
        });
        if (!employer)
            return res.status(400).json({
                message: "User doesn't exist"
            });

        const isMatch = await bcrypt.compare(password, employer.password);
        if (!isMatch)
            return res.status(400).json({
                message: "Incorrect Password !"
            });

        res.status(200).json(employer);

    } catch (error) {
        res.status(400).json({ error: error.message })
    }
}

const readEmployee = async (req, res) => {
    try {
        const { id } = req.params;
        const employee = await Employee.findById(id);
        res.status(200).json(employee);
    } catch (error) {
        res.status(400).json({ error: error.message })
    }
}

const updateEmployee = async (req, res) => {
    try {
        const { id } = req.params;
        if (req.body.resume)
            req.body.resume = await uploadFile(req.body.resume);
        const employee = { ...req.body, _id: id };
        await Employee.findByIdAndUpdate(id, employee, { new: true })
        res.status(201).json(employee);

    } catch (error) {
        res.status(400).json({ error: error.message })
    }
}

// const deleteUser = async (req, res) => {
//     const { id } = req.params;
//     try {
//         await User.findByIdAndRemove(id)
//         res.status(201).json({ message: "User deleted successfully" });
//     } catch (error) {
//         res.status(400).json({ error: error.message })
//     }
// }



module.exports = {
    login,
    signUp,
    readEmployee,
    updateEmployee,
    loginEmployer
    // deleteUser
}
