const express = require('express');
const { login, signUp, readEmployee, deleteUser, updateEmployee, loginEmployer } = require('../controllers/auth');

const routerEmployee = express.Router();
routerEmployee.get('/:id', readEmployee)
routerEmployee.post('/login', login);
routerEmployee.post('/signup', signUp);
routerEmployee.put('/:id', updateEmployee)
// router.delete('/:id', deleteUser)

const routerEmployer = express.Router();
routerEmployer.post('/login', loginEmployer);

module.exports = {
    routerEmployee,
    routerEmployer
};
