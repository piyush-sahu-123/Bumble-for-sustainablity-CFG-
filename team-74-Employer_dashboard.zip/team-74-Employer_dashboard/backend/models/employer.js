const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const employerSchema = new Schema({
    email: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    },
    applied_users: {
        type: Array,
        required: false
    },
    rejected_users: {
        type: Array,
        required: false
    },
    accepted_users: {
        type: Array,
        required: false
    }
});

const Employer = mongoose.model('employer', employerSchema)

module.exports = {
    Employer
}
