const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const employeeSchema = new Schema({
    username: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    phone_no: {
        type: String,
        required: false
    },
    dob: {
        type: Date,
        required: false
    },
    description: {
        type: String,
        required: false
    },
    qualification: {
        type: String,
        required: false
    },
    resume: {
        type: String,
        required: false
    },
    linked_in: {
        type: String,
        required: false
    },
    role: {
        type: String,
        required: false
    },
    sector: {
        type: Array,
        required: false
    },
    city: {
        type: String,
        required: false
    },
    state: {
        type: String,
        required: false
    }
}, { timestamps: true });

const Employee = mongoose.model('Employee', employeeSchema);
module.exports = {
    Employee
};
