const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const referralSchema = new Schema({
    hashcode: {
        type: String,
        required: true
    }
});

const Referral = mongoose.model('referral', referralSchema)

module.exports = {
    Referral
}
