import React from 'react'

export default function NavbarEmployee() {
    const logout = () => {
        localStorage.removeItem('userId');
        window.location.href = "/"
    }
    return (
        <nav class="navbar navbar-expand-lg navbar-light bg-light sticky-top">
            <div class="container-fluid">
                <span class="navbar-brand">Hi User</span>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link active" href='/dashboard'>Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href='/profile'>Profile</a>
                        </li>
                        <li class="nav-item" style={{cursor: 'pointer'}}>
                            <span class="nav-link active" onClick={logout}>Logout</span>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    )
}
