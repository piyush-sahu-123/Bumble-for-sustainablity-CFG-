import React from 'react'
import './BannerStyle.css'
export default function Banner() {
  return (
    <div class="banner">

<div class="container titletext" >
        <h2 class="title">Making Sustainability </h2>
        <h3 class="title">The Default Choice...</h3>
        <p class="moto">Join the commumity | Little Steps Matter</p>
        </div>
    </div>
  )
}
