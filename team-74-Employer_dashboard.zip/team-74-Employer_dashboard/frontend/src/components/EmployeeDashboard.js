import React from 'react'

function EmployeeDashboard() {
  return (
    <div>Employee Dashboard Component</div>
  )
}

export default EmployeeDashboard