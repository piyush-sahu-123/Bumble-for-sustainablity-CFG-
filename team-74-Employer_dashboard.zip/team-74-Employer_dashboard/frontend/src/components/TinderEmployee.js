import React, { useState, useEffect, useMemo, useRef } from 'react'
// import TinderCard from '../react-tinder-card/index'
import TinderCard from 'react-tinder-card'
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import  './TinderEmployeeStyle.css'
//import  s from './images/s.png'


const db = [
  {
    name: 'Richard Hendricks',
    url: './img/richard.jpg'
  },
  {
    name: 'Erlich Bachman',
    url: './img/erlich.jpg'
  },
  {
    name: 'Monica Hall',
    url: './img/monica.jpg'
  },
  {
    name: 'Jared Dunn',
    url: './img/jared.jpg'
  },
  {
    name: 'Dinesh Chugtai',
    url: './img/dinesh.jpg'
  }
]

function Advanced () {
  useEffect(() => {
    let db =[];
    axios.get('http://localhost:5000/api/employees', {
      "headers": {
        "content-type": "application/json",
        "Authorization": "Bearer " ,
      },
    })
    .then(res => {
      db=res.data;
      console.log(db);
    })
  }, []);
  const [acceptedList, setAcceptedList] = useState([]);
  const [rejectedList, setRejectedList] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(db.length - 1)
  const [lastDirection, setLastDirection] = useState()
  // used for outOfFrame closure
  const currentIndexRef = useRef(currentIndex)

  const childRefs = useMemo(
    () =>
      Array(db.length)
        .fill(0)
        .map((i) => React.createRef()),
    []
  )

  const handleSubmit = () => {
    const id = localStorage.getItem('id');
    const params=JSON.stringify({
      id:id,
      acceptedList:acceptedList,
      rejectedList:rejectedList
    });
    axios.post('http://localhost:5000/api/addLists', params, {
      "headers": {
        "content-type": "application/json",
        "Authorization": "Bearer " ,
      },
    })
    .then(res => {
      console.log(res);
    }
    )
  }


  const updateCurrentIndex = (val) => {
    setCurrentIndex(val)
    currentIndexRef.current = val
  }

  const canGoBack = currentIndex < db.length - 1

  const canSwipe = currentIndex >= 0

  // set last direction and decrease current index
  const swiped = (direction, nameToDelete, index) => {
    if(direction === 'right'){
      setAcceptedList([...acceptedList, db[index]._id]);
    }
    else{
      setRejectedList([...rejectedList, db[index]._id]);
    }
    setLastDirection(direction)
    updateCurrentIndex(index - 1)
  }

  const outOfFrame = (name, idx) => {
    console.log(`${name} (${idx}) left the screen!`, currentIndexRef.current)
    // handle the case in which go back is pressed before card goes outOfFrame
    currentIndexRef.current >= idx && childRefs[idx].current.restoreCard()
    // TODO: when quickly swipe and restore multiple times the same card,
    // it happens multiple outOfFrame events are queued and the card disappear
    // during latest swipes. Only the last outOfFrame event should be considered valid
  }

  const swipe = async (dir) => {
    if (canSwipe && currentIndex < db.length) {
      await childRefs[currentIndex].current.swipe(dir) // Swipe the card!
    }
  }

  // increase current index and show card
  const goBack = async () => {
    if (!canGoBack) return
    const newIndex = currentIndex + 1
    updateCurrentIndex(newIndex)
    await childRefs[newIndex].current.restoreCard()
  }
  
  let [employees, setEmployees] = useState({
    name:"keerthana",
    description:"3 years experience in sustainability firm",
    qualification:"B.Tech",
    linkedIn:"",
    address:{city:"hyderabad",state:"Telangana"}
  })
  
  
  return (
      <div className='tinderContent container text-white' >
        {/* <h1> Hey Employer!</h1> <br /> */}
    <div className='tinderBody'>
      <link
        href='https://fonts.googleapis.com/css?family=Damion&display=swap'
        rel='stylesheet'
      />
      <link
        href='https://fonts.googleapis.com/css?family=Alatsi&display=swap'
        rel='stylesheet'
      />
      {/* {lastDirection ? (
        <h2 key={lastDirection} className='infoText'>
          You swiped {lastDirection}
        </h2>
      ) : (
        <h2 className='infoText'>
          Swipe a card or press a button to get Restore Card button visible!
        </h2>
      )} */}
      <h1>Employer cards</h1>
      <div className='cardContainer'>
        {db.map((user, index) => (
          <TinderCard
            ref={childRefs[index]}
            className='swipe'
            key={user.username}
            onSwipe={(dir) => swiped(dir, user.username, index)}
            onCardLeftScreen={() => outOfFrame(user.username, index)}
          >
            <div className='card'>
              <div className="card-header text-dark">
              <b> {user.username} </b>
              </div>
              <ul className="list-group list-group-flush">
                <li className="list-group-item"><b>Description:</b> {user.description}</li>
                <li className="list-group-item"><b>Qualification:</b> {user.qualification}</li>
                <li className="list-group-item"><b>LinkedIn:</b>{user.linkedIn}</li>
                <li className="list-group-item"><b>Address:</b> <br></br>{user.city} {user.state}</li>
              </ul>
            </div>
          </TinderCard>
        ))}
      </div>
      <br />
      <div className='buttons bt'>
        <Button style={{ backgroundColor: !canSwipe && '#c3c4d3'  }} onClick={() => swipe('left')}>Swipe left!</Button>
        <Button   style={{ backgroundColor: !canSwipe && '#c3c4d3' }} onClick={() => swipe('right')}>Swipe right!</Button>
      <Button className='swipeundo' style={{ backgroundColor: !canGoBack && '#c3c4d3' }} onClick={() => goBack()}>Undo swipe!</Button>
      </div>
      
      
      {lastDirection ? (
        <h2 key={lastDirection} className='infoText'>
          You swiped {lastDirection}
        </h2>
      ) : (
        <h2 className='infoText'>
          Swipe a card or press a button to get Restore Card button visible!
        </h2>
      )}
      <div>
        <Button className='dvp' variant = "primary" onClick={handleSubmit}> Done Viewing the Profiles </Button>
      </div>
    </div>
    </div>
  )
}

export default Advanced;