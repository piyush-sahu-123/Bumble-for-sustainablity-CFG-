import React from 'react'
import './CompanyLogoStyle.css'
export default function CompanyLogo() {
    return (
        <div class="companylogo">
            <div class="container">
                <h1 style={{ textAlign: 'center' }}> </h1>
                <div className="row" style={{ marginTop: '50px' }}>
                    <div className="col-md-3">
                        <div className="container">
                            <a href='https://www.dexlerenergy.com/' style={{ textDecoration: 'none' }}>
                                <div className="card">
                                    <img className="p1" src="https://media-private.canva.com/xE59U/MAErSxxE59U/1/s.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAJWF6QO3UH4PAAJ6Q%2F20220604%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20220604T022856Z&X-Amz-Expires=78257&X-Amz-Signature=26a92feb8de535f27e6b1469b287124be9d116dc69440d3fde175ef80e62d047&X-Amz-SignedHeaders=host&response-expires=Sun%2C%2005%20Jun%202022%2000%3A13%3A13%20GMT" style={{ height: "100px" }}
                                        alt="Avatar" />
                                    
                                </div>
                            </a>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="container">
                            <a href='https://www.upcyclerslab.com/?utm_source=affiliate&utm_medium=direct&utm_campaign=affiliate_219&utm_term=affiliatemarketing&ref=messold&utm_content=https://www.google.com/' style={{ textDecoration: 'none' }}>
                                <div className="card">
                                    <img className="p1" src="https://media-private.canva.com/GfgwQ/MAErSyGfgwQ/1/s.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAJWF6QO3UH4PAAJ6Q%2F20220604%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20220604T032907Z&X-Amz-Expires=73497&X-Amz-Signature=c6797840c81c3573be769ecb9dc051c584adee13e0146a123254e1ddfc9451f6&X-Amz-SignedHeaders=host&response-expires=Sat%2C%2004%20Jun%202022%2023%3A54%3A04%20GMT" style={{ height: "100px" }}
                                        alt="Avatar" />
                                    
                                </div>
                            </a>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="container">
                            <a href='https://pitchbook.com/profiles/company/489115-81' style={{ textDecoration: 'none' }}>
                                <div className="card">
                                    <img className="p1" src="https://media-private.canva.com/xADoE/MAErS9xADoE/1/s.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAJWF6QO3UH4PAAJ6Q%2F20220604%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20220604T142606Z&X-Amz-Expires=35126&X-Amz-Signature=15e175a2b6252ef217897dd3ee353e5468c53de9cbd0ccced5f40de9d3c46e7c&X-Amz-SignedHeaders=host&response-expires=Sun%2C%2005%20Jun%202022%2000%3A11%3A32%20GMT" style={{ height: "100px" }}
                                        alt="Avatar" />
                                    
                                </div>
                            </a>
                        </div>
                    </div>
                    <div className="col-md-3">
                        <div className="container">
                            <a href='https://www.devic-earth.com/' style={{ textDecoration: 'none' }}>
                                <div className="card">
                                    <img className="p1" src="https://media-private.canva.com/82pV4/MAErS582pV4/1/s.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=AKIAJWF6QO3UH4PAAJ6Q%2F20220604%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20220604T002551Z&X-Amz-Expires=85876&X-Amz-Signature=48c14ad91e8a17e60f7bb9bc1153bfc3058e2e03b8c761828856e344b1cbef5d&X-Amz-SignedHeaders=host&response-expires=Sun%2C%2005%20Jun%202022%2000%3A17%3A07%20GMT" style={{ height: "100px" }}
                                        alt="Avatar" />
                                    
                                </div>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    )
}
