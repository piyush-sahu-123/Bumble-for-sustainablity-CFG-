import React from "react";
import { useForm } from "react-hook-form";
import { loginEmployer } from "../functions/employee-auth";
import { Link } from "react-router-dom";

const EmployersLogin = () => {
  const [loading, setLoading] = React.useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onFormsubmit = async (userobj) => {
    setLoading(true);
    if (userobj.email && userobj.password) {
      const params = {
        email: userobj.email,
        password: userobj.password,
      };
      const result = await loginEmployer(params);
      if (result !== null) {
        localStorage.setItem("userId", result._id);
        window.location.href = "employeer/profile";
      }
    }
    setLoading(false);
  };
  return (
    <div>
      <div className="col-sm-12 col-md-6 col-lg-6 mx-auto mt-5 p-5 mb-4">
        <div className="card p-0 overflow-hidden h-100 shadow mx-3">
          <div className="card-body">
            <form onSubmit={handleSubmit(onsubmit)} className="mx-auto">
              <h2
                className="text-center"
                style={{ color: "rgb(200, 246, 135)" }}
              >
                Employer Login
              </h2>

              <div className="form-row">
                <div className="form-group col-xl-10 mb-3 mx-2">
                  <label htmlFor="inputusername" className="mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    className="form-control mb-3"
                    id="inputemail"
                    placeholder="email"
                    {...register("email", { required: true })}
                  />
                </div>
                <div className="form-group col-xl-10 mb-3 mx-2">
                  <label htmlFor="inputusername" className="mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    className="form-control mb-3"
                    id="inputpassword"
                    placeholder="password "
                    {...register("password", { required: true })}
                  />
                </div>
              </div>
              <div className="text-center">
                <button
                  disabled={loading}
                  type="submit"
                  className="btn btn-success my-1"
                >
                  Login
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployersLogin;
