import React from "react";
import { useState, useEffect } from "react";
import { readEmployee, updateEmployee } from "../functions/employee-auth";
import "./EmployeeProfileStyle.css";

var sector = [];
export default function EmployeeProfile() {
  
  useEffect(() => {
    async function fetchData() {
      const userId = localStorage.getItem("userId");
      const res = await readEmployee(userId);
      setEmployee(res);  
    }
    fetchData()
  }, [])

  const [employee, setEmployee] = useState({})
  const [inputs, setInputs] = useState({});
  const handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    if (name === "sector") {
      if (!sector.includes(value)) sector.push(value);
      else sector = sector.filter((val) => val !== value);
      setInputs((values) => ({ ...values, [name]: sector }));
    } else setInputs((values) => ({ ...values, [name]: value }));
  };

  const handleSubmit = async (event) => {
    console.log({...inputs, ...employee})
    event.preventDefault();
    const userId = localStorage.getItem("userId");
    const res = await updateEmployee(userId, {...inputs, ...employee});
    console.log({...inputs, ...employee})
    // if(res) {
    //   window.location.href = "/dashboard";
    // }
  };

  return (
    <div class="content">
      <div class="container">
        <div class="row align-items-stretch no-gutters contact-wrap">
          <form
            class="mb-5"
            id="contactForm"
            name="contactForm"
            onSubmit={handleSubmit}
            onChange={handleChange}
          >
            <div class="row">
              <div class="col-md-6">
                <div class="form h-100">
                  <h2>Set Your Profile</h2>
                  <div class="row">
                    <div class="col-md-12">
                      <div class="row">
                        <div class="col-md-6 form-group mb-5">
                          <label
                            for=""
                            class="col-form-label"
                            style={{ color: "black" }}
                          >
                            Name{" "}
                            <span style={{ color: "red", fontSize: "20px" }}>
                              *
                            </span>
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            name="username"
                            id="username"
                            value={employee && employee.username ? employee.username : "Your name"}
                            required
                          />
                        </div>
                        <div class="col-md-6 form-group mb-5">
                          <label
                            for=""
                            class="col-form-label"
                            style={{ color: "black" }}
                          >
                            Email{" "}
                            <span style={{ color: "red", fontSize: "20px" }}>
                              *
                            </span>
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            name="email"
                            id="email"
                            value={employee && employee.email !== undefined ? employee.email : "Email"}
                            disabled={true}
                            required
                          />
                        </div>
                      </div>

                      <div class="row">
                        <div class="col-md-6 form-group mb-5">
                          <label
                            for="phone_no"
                            class="col-form-label"
                            style={{ color: "black" }}
                          >
                            Phone{" "}
                            <span style={{ color: "red", fontSize: "20px" }}>
                              *
                            </span>
                          </label>
                          <input
                            type="tel"
                            class="form-control"
                            name="phone_no"
                            id="phone_no"
                            placeholder="Phone"
                            required
                          />
                        </div>
                        <div class="col-md-6 form-group mb-5">
                          <label
                            for=""
                            class="col-form-label"
                            style={{ color: "black" }}
                          >
                            DOB{" "}
                            <span style={{ color: "red", fontSize: "20px" }}>
                              *
                            </span>
                          </label>
                          <input
                            type="date"
                            class="form-control"
                            name="DOB"
                            id="DOB"
                            placeholder="DOB"
                            required
                          />
                        </div>
                      </div>

                      <div class="row">
                        <div class="col-md-6 form-group mb-5">
                          <label
                            for=""
                            class="col-form-label"
                            style={{ color: "black" }}
                          >
                            City{" "}
                            <span style={{ color: "red", fontSize: "20px" }}>
                              *
                            </span>
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            name="city"
                            id="city"
                            placeholder="City"
                            required
                          />
                        </div>
                        <div class="col-md-6 form-group mb-5">
                          <label
                            for=""
                            class="col-form-label"
                            style={{ color: "black" }}
                          >
                            State{" "}
                            <span style={{ color: "red", fontSize: "20px" }}>
                              *
                            </span>
                          </label>
                          <input
                            type="text"
                            class="form-control"
                            name="city"
                            id="city"
                            placeholder="City"
                            required
                          />
                        </div>
                      </div>

                      <div class="row">
                        <div class="col-md-12 form-group mb-5">
                          <label
                            for="description"
                            class="col-form-label"
                            style={{ color: "black" }}
                          >
                            Describe Yourself{" "}
                            <span style={{ color: "red", fontSize: "20px" }}>
                              *
                            </span>
                          </label>
                          <textarea
                            class="form-control"
                            name="description"
                            id="description"
                            cols="30"
                            rows="4"
                            placeholder="Write about yourself..."
                            required
                          ></textarea>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-6">
                <div class="form h-100">
                  <div class="row">
                    <div class="col-md-6 form-group mb-5">
                      <label
                        for=""
                        class="col-form-label"
                        style={{ color: "black" }}
                      >
                        Qualification{" "}
                        <span style={{ color: "red", fontSize: "20px" }}>
                          *
                        </span>
                      </label>
                      <select
                        class="form-select"
                        aria-label="Default select example"
                        id="qualification"
                        name="qualification"
                        required
                      >
                        <option selected>Your Degree</option>
                        <option value="MBA">MBA</option>
                        <option value="Btech">Btech</option>
                        <option value="mtech">Mtech 3</option>
                      </select>
                    </div>
                    <div class="col-md-6 form-group mb-5">
                      <label
                        for=""
                        class="col-form-label"
                        style={{ color: "black" }}
                      >
                        Resume{" "}
                        <span style={{ color: "red", fontSize: "20px" }}>
                          *
                        </span>
                      </label>
                      <input
                        type="file"
                        class="form-control"
                        name="resume"
                        id="resume"
                        required
                      />
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-6 form-group mb-5">
                      <label
                        for="linked_in"
                        class="col-form-label"
                        style={{ color: "black" }}
                      >
                        LinkedIn
                      </label>
                      <input
                        type="text"
                        class="form-control"
                        name="linked_in"
                        id="linked_in"
                        placeholder="LinkedIn Id"
                      />
                    </div>
                    <div class="col-md-6 form-group mb-5">
                      <label
                        for=""
                        class="col-form-label"
                        style={{ color: "black" }}
                      >
                        Role{" "}
                        <span style={{ color: "red", fontSize: "20px" }}>
                          *
                        </span>
                      </label>
                      <select
                        class="form-select"
                        aria-label="Default select example"
                        name="role"
                        id="role"
                        required
                      >
                        <option value="MBA" selected>
                          HR
                        </option>
                        <option value="Digital Marketing">
                          Digital Marketing
                        </option>
                        <option value="Technologist">Technologist</option>
                      </select>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-md-12 form-group mb-5">
                      <label
                        for="message"
                        class="col-form-label"
                        style={{ color: "black" }}
                      >
                        Choose your Sector{" "}
                        <span style={{ color: "red", fontSize: "20px" }}>
                          *
                        </span>
                      </label>
                      <div className="Sector">
                        <input
                          type="checkbox"
                          id="Water"
                          name="sector"
                          value="Water"
                        />{" "}
                        Water
                        <br />
                        <input
                          type="checkbox"
                          id="Fire"
                          name="sector"
                          value="Fire"
                        />{" "}
                        Fire
                        <br />
                        <input
                          type="checkbox"
                          id="Heart"
                          name="sector"
                          value="Heart"
                        />{" "}
                        Heart
                        <br />
                        <input
                          type="checkbox"
                          id="Air"
                          name="sector"
                          value="Air"
                        />{" "}
                        Air
                        <br />
                        <input
                          type="checkbox"
                          id="Other"
                          name="sector"
                          value="Other"
                        />{" "}
                        Other
                        <br />
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-12 form-group">
                      <input
                        type="submit"
                        value="Submit"
                        class="btn btn-primary rounded-0 py-2 px-4"
                      />
                      <span class="submitting"></span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
