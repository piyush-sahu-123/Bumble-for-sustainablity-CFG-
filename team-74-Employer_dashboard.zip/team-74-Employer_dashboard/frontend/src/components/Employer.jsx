import Navbar from './Navbar';
import Content from './Content';
import Tinder from './Tinder';
import './Employer.css'
import './index.css'

function Employer() {
    const [role, setRole] = useState('');
    return (
        <div>
            <Navbar />
            <Content role={role}/>
            <Tinder role={role} />
         </div>   
        )
    }

export default Employer;