import React from 'react'
import NavbarEmployee from './NavbarEmployee'
import HomeNav from './HomeNav'

export default function Header() {
    return (
      
      <>
      { localStorage.getItem("userId") !== null?<NavbarEmployee />:<HomeNav />}
      </>
  )
}
