import React from "react";
import { useForm } from "react-hook-form";
import { login } from "../functions/employee-auth";
function Login() {
  const [loading, setLoading] = React.useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onsubmit = async (userdata) => {
    setLoading(true);
    if (userdata.email && userdata.password) {
      const params = {
        email: userdata.email,
        password: userdata.password,
      };
      const result = await login(params);
      if (result !== null) {
        localStorage.setItem("userId", result._id);
        window.location.href = "/dashboard";
      }
    }
    setLoading(false);
  };

  return (
    <div>
      <div className="col-sm-12 col-md-6 col-lg-6 mx-auto mt-5 p-5 mb-4">
        <div className="card p-0 overflow-hidden h-100 shadow mx-3">
          <div className="card-body">
            <form onSubmit={handleSubmit(onsubmit)} className="mx-auto">
              <h2
                className="text-center"
                style={{ color: "rgb(200, 246, 135)" }}
              >
                Employee Login
              </h2>
              <div className="form-row">
                <div className="form-group col-xl-10 mb-3 mx-2">
                  <label htmlFor="inputusername" className="mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    className="form-control mb-3"
                    id="inputemail"
                    placeholder="email"
                    {...register("email", { required: true })}
                  />
                </div>
                <div className="form-group col-xl-10 mb-3 mx-2">
                  <label htmlFor="inputusername" className="mb-2">
                    Password
                  </label>
                  <input
                    type="password"
                    className="form-control mb-3"
                    id="inputpassword"
                    placeholder="password "
                    {...register("password", { required: true })}
                  />
                </div>
              </div>
              <div className="text-center">
                <button
                  disabled={loading}
                  type="submit"
                  className="btn btn-success my-1"
                >
                  Login
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Login;
