import React from 'react'
import HomeNav from './HomeNav'
import Banner from './Banner'
import CompanyLogo from './CompanyLogo'
import NavbarEmployee from './NavbarEmployee'
import { useEffect, useState } from 'react'
export default function HomePage() {
  
  return (
    
    <>
    

<Banner />
<CompanyLogo />
    </>
  )
}
