// import { Link, Redirect } from "react-router-dom";
import React, { useState } from "react";
// import { Button } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import axios from 'axios';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import {CopyToClipboard} from 'react-copy-to-clipboard';
// import {get_referral} from '../functions/employee-auth'
const NavBar = (props) => {
    const [email, setEmail] = useState('');

    let state = {
        value: '',
        copied: false,
      };
    let Referral="gg";
    const HandleReferral = (e) => {
        const email = document.getElementById('id').value;
        const params = JSON.stringify({
            "email": email,
        });
        // Referral = get_referral(params);
        // axios.get('/api/getReferral', params, {
        //     "headers": {
        //       "content-type": "application/json",
        //       "Authorization": "Bearer " ,
        //     },
        //   })
        //     .then((res) => {
        //       Referral = res.data;
        //       this.state.value=Referral;
        //     })
        //     .catch(err => {
        //       console.error(err);
        //       window.location.href = '/#/'
        //     });
    }

    const [copied, setCopied] = useState(false);
	return (

		<nav className="navbar m-3">
			{/* Hamburger */}
			{/* <span className="material-icons hamburger" onClick={handleClick}>menu</span> */}
			
			<h1 className="logo">
				SusMafia
			</h1>

            <div className="referral">
                <input id="input" placeholder="Enter the Email" />
                <Button variant="primary" className="ref" onClick={HandleReferral}>Get Referral</Button>
                {/* <ContentCopyIcon /> */}
                <CopyToClipboard text={Referral} onCopy={() => setCopied(true)}>
                    <Button variant="primary" className="ref"><ContentCopyIcon /></Button>
                </CopyToClipboard>

            </div>
		</nav>
	);
}

export default NavBar;