import * as api from '../apis';

export const signUp = async (employee) => {
    try {
        const { data } = await api.signUp(employee);
        return data
    } catch (error) {
        console.log(error)
    }
}

export const login = async (employee) => {
    try {
        const { data } = await api.login(employee);
        return data
    } catch (error) {
        console.log(error)
    }
}

export const loginEmployer = async (employer) => {
    try {
        const { data } = await api.login(employer);
        return data
    } catch (error) {
        console.log(error)
    }
}

export const readEmployee = async (id) => {
    try {
        const { data } = await api.readEmployee(id);
        return data
    } catch (error) {
        console.log(error)
    }
}

export const updateEmployee = async (id, employee) => {
    try {
        console.log(employee)
        const { data } = await api.updateEmployee(id, employee);
        return data
    } catch (error) {
        console.log(error)
    }
}