import axios from "axios";

const url = "http://localhost:5000";

/* Authentication and employee and employer Requests */
export const signUp = newEmployee => axios.post(`${url}/employee/signup`, newEmployee);
export const login = employee => axios.post(`${url}/employee/login`, employee);
export const readEmployee = id => axios.get(`${url}/employee/${id}`);
export const updateEmployee = (id, employee) => axios.put(`${url}/employee/${id}`, employee);
export const loginEmployer = employer => axios.post(`${url}/employer/login`, employer);
