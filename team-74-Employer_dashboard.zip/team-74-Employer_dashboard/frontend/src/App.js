import React from "react";
import Login from "./components/Login.js";
import EmployerLogin from "./components/EmployerLogin.js";
import HomePage from './components/HomePage';
import EmployeeProfile from "./components/EmployeeProfile.js";
import EmployeeDashboard from "./components/EmployeeDashboard.js";
import { Route, Routes } from "react-router-dom";

function App() {
  return (
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<EmployeeDashboard />} />
        <Route path="/profile" element={<EmployeeProfile />} />
        <Route path="employer/login" element={<EmployerLogin />} />
        <Route path="employer/profile" element={<EmployerLogin />} />
      </Routes>
  );
}

export default App;
